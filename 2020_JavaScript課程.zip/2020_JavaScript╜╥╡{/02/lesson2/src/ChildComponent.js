import React from 'react';

class ChildComponent extends React.Component{

    constructor(props) {
        super(props);
    }

    render(){
        return(
            <div style={{marginTop:'1em'}}>
                {this.props.childInfo}
            </div>
        )

    }
}

export default ChildComponent;