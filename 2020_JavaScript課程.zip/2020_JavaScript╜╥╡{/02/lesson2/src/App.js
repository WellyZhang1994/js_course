import React from 'react';
import AppChild from './AppChild'
import { BrowserRouter, Route, Switch } from 'react-router-dom'

class App extends React.Component{

  render(){
    
    return(
        <BrowserRouter>
          <Switch>
            <Route exact path='/' component={AppChild}></Route>
          </Switch>
        </BrowserRouter>
    )
  }
}


export default App;
