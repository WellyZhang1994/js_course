import React from 'react';
import ChildComponent from './ChildComponent'

class AppChild extends React.Component{

    constructor(props) {
        super(props);
        // init state
        this.state = {
            hello:'Hello',
            childOpen: false
        }
    }

    // after render()
    componentDidMount(){
        this.setState({hello:'1234'})
    }

    // button event
    /*
        buttonOnClick = function(){
            this.setState({hello:'World'})
        }
    */
    buttonOnClick = () => {
        this.setState({hello:'World'})
    }

    // after any state change
    componentDidUpdate(prevProps, prevState, snapshot){
        //console.log(prevProps)
        //console.log(prevState)
        //console.log(snapshot)
    }

    
    changeRenderChild = () =>{
        // original 
        this.setState({childOpen: !this.state.childOpen})

        /* 
        // better
        this.setState((prevState, props)=>({
            childOpen : !prevState.childOpen
        }))
        */
    }


    render(){
        return(
            <React.Fragment>
                <div>
                    {`Hello : ${this.state.hello}`}
                </div>
                <button style={{marginTop:'1em', marginRight:'1em'}} onClick={this.buttonOnClick}>Change World</button>
                <button  style={{marginTop:'1em'}} onClick={()=>this.setState({hello:'Hello'})}>Change Hello</button>
                <br/>
                
                <button  style={{marginTop:'1em'}} onClick={()=> this.changeRenderChild()}>render child component</button>

                {/* childInfo 就是 ChildComponent 中的 Props */}
                {this.state.childOpen ? <ChildComponent childInfo={'This is child'}/> : ''}

            </React.Fragment>
        )
    }
}


export default AppChild;
