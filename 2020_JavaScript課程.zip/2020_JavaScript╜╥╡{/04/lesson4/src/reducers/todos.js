
const todos = (state = [], action) => {
  // action -> dispatch -> 判斷action type -> 藉由return更新store
  switch (action.type) {
    case 'ADD_TODO':
      return [
        ...state,
        {
          text: action.payload
        }
      ]
    case 'REMOVE_TODO':
      return [...state.filter(x=> x.text !== action.payload)]
    default:
      return state
  }
}
export default todos
