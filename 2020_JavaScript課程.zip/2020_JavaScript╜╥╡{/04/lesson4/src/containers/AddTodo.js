import React from 'react'
import { connect } from 'react-redux'
import { addTodo,removeTodo } from '../actions'

class AddTodo extends React.Component{

  render(){
    let input

    return (
      <div>
        <form onSubmit={e => {
  
          //取消跳轉頁面，預設流覽器在做完一些事情，像是form submit就會刷新頁面，這裡禁止他刷新 
          e.preventDefault()
          if (!input.value.trim()) {
            return
          }
  
          // 關鍵點 : 把想要存起來的東西，用action包起來 -> 啟動dispatch -> 送到Reducer -> 更新Store -> 重新render頁面
          this.props.addTodo(input.value)
  
          input.value = ''
        }}>
          <input ref={node => input = node} />
          <button type="submit">
            Add Todo
          </button>
        </form>
  
        <br/>
        <br/>
  
        <div>
          {/* todo會從store取出，利用es6功能，對他map一個一個取出來繪製*/}
          {this.props.todo.map((x,index)=>{
            return(
              <React.Fragment key={index}>
                <span > {`${index} -> ${x.text}`} </span>
                <button onClick={()=>{this.props.removeTodo(x.text)}}> Remove</button>
                <br/>
              </React.Fragment>
            )
          })}
        </div>
      </div>
    )
  }
  
}

//將狀態樹裡面的state取出，轉換成component可以用的props
const mapStateToProps = (state) => ({
    todo : state.todos
})

//connect( {state to props} , { dispatch to props } )("component name")
export default connect(mapStateToProps, {addTodo,removeTodo} )(AddTodo)
