//注意是
// export const functionName() {}
// export default (){}

export const addTodo = text => {
  // text 由外部傳入
  // 組成 action 物件
  return {
    type: 'ADD_TODO',
    payload: text
  }
}


export const removeTodo = text => {
  // text 由外部傳入
  // 組成 action 物件
  return {
    type: 'REMOVE_TODO',
    payload: text
  }
}