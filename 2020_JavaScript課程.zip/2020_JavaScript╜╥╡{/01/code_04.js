let myVar = "outer"

function func(){
  console.log(myVar)
  myVar = "inner"
}

func()
console.log(myVar)


/*
function func2(){
  var myVar2 = "inner"
}
func2()
console.log(myVar2)
*/



/*
var myVar3 = "global";
function outer(){
  var myVar3 = "outer";
  function inner(){
    console.log(myVar3); // Q4=?
  }
  inner();
}
outer();
*/