//非匿名函式 名稱為test
function test(r){
	return r * r * 3.14
}
// 這叫匿名涵式, function本身沒有名稱
let circleArea = function(r) {
    return r * r * 3.14
}

// 箭頭函數寫法
let circleArea2 = r => r * r * 3.14;
// 箭頭涵式改寫

let circleArea3 = (r) => {
	return r * r * 3.14
}

console.log(test(10))