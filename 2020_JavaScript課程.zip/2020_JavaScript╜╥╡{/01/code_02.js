let arr = ['a', 'b', 'c', 'd'];

// for...in 取得 "鍵名/屬性名"
for (let key in arr) {
    console.log(key); // '0' '1' '2' '3'
}

// for...of 取得 "鍵值/屬性值"
for (let value of arr) {
    console.log(value); // 'a' 'b' 'c' 'd'
}


// 使用在字串上
let string = 'Hello';

for (let i of string) {
    console.log(i); // 'H' 'e' 'l' 'l' 'o'
}


for(i in arr){
	console.log(i)
}