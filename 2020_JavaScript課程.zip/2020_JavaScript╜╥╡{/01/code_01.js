for ( var i=0 ; i<5 ; i++){
	setTimeout(()=>{
		console.log('var :' + i)
	},100)
	console.log('hi :' + i)
}

/*
for ( let i=0 ; i<5 ; i++){
	setTimeout(()=>{
		console.log('let :' + i)
	},100)
	console.log('hi :' + i)
}
*/